-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-09-2021 a las 04:24:47
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `fonasa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consulta`
--

CREATE TABLE `consulta` (
  `id_consulta` int(11) NOT NULL,
  `id_hospital` int(11) NOT NULL,
  `id_tipoconsulta` int(11) NOT NULL,
  `cant_pacientes` int(11) NOT NULL,
  `nom_especialista` varchar(255) NOT NULL,
  `estado` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `consulta`
--

INSERT INTO `consulta` (`id_consulta`, `id_hospital`, `id_tipoconsulta`, `cant_pacientes`, `nom_especialista`, `estado`) VALUES
(1, 1, 3, 3, 'pedro gutierrez', 'SALA DE ESPERA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hospital`
--

CREATE TABLE `hospital` (
  `id_hospital` int(11) NOT NULL,
  `nom_hospital` varchar(255) NOT NULL,
  `direccion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `hospital`
--

INSERT INTO `hospital` (`id_hospital`, `nom_hospital`, `direccion`) VALUES
(1, 'Hospital Padre Hurtado', 'Esperanza 2150, San Ramón, Región Metropolitana'),
(2, 'Complejo Hospitalario San José de Maipo', 'Comercio 19856, San José de Maipo, Región Metropolitana'),
(3, 'CRS Hospital Provincia Cordillera', 'Av. Eyzaguirre 2061, Puente Alto, Región Metropolitana'),
(4, 'Hospital Dr. Luis Tisné Brousse', 'Av. Las Torres 5150, Santiago, Peñalolén, Región Metropolitana'),
(5, 'Hospital Barros Luco Trudeau', 'Gran Avenida Jose Miguel Carrera 3204, Santiago, San Miguel, Región Metropolitana');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

CREATE TABLE `paciente` (
  `id_paciente` int(11) NOT NULL,
  `id_hospital` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `edad` int(11) NOT NULL,
  `num_historiaclinica` int(11) NOT NULL,
  `relacion_pesoestatura` int(11) DEFAULT NULL,
  `fumador` tinyint(1) DEFAULT NULL,
  `años_fumador` int(11) DEFAULT NULL,
  `tiene_dieta` tinyint(1) DEFAULT NULL,
  `prioridad` double NOT NULL,
  `riesgo` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `paciente`
--

INSERT INTO `paciente` (`id_paciente`, `id_hospital`, `nombre`, `edad`, `num_historiaclinica`, `relacion_pesoestatura`, `fumador`, `años_fumador`, `tiene_dieta`, `prioridad`, `riesgo`) VALUES
(1, 1, 'gabriela alejandra', 9, 423958375, 3, NULL, NULL, NULL, 5, 0.45),
(2, 1, 'diego ignacio', 23, 295489078, NULL, 0, 0, NULL, 2, 0.46),
(3, 1, 'freddy alejandro', 49, 394370157, NULL, NULL, NULL, 0, 4.63, 7.5687);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_consulta`
--

CREATE TABLE `tipo_consulta` (
  `id_tipoconsulta` int(11) NOT NULL,
  `nom_tipo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipo_consulta`
--

INSERT INTO `tipo_consulta` (`id_tipoconsulta`, `nom_tipo`) VALUES
(1, 'Pediatría'),
(2, 'Urgencia'),
(3, 'CGI (Consulta General Integral)');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `consulta`
--
ALTER TABLE `consulta`
  ADD PRIMARY KEY (`id_consulta`),
  ADD KEY `id_hospital` (`id_hospital`),
  ADD KEY `id_tipoconsulta` (`id_tipoconsulta`);

--
-- Indices de la tabla `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`id_hospital`);

--
-- Indices de la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD PRIMARY KEY (`id_paciente`),
  ADD UNIQUE KEY `num_historiaclinica` (`num_historiaclinica`),
  ADD KEY `id_hospital` (`id_hospital`),
  ADD KEY `id_hospital_2` (`id_hospital`);

--
-- Indices de la tabla `tipo_consulta`
--
ALTER TABLE `tipo_consulta`
  ADD PRIMARY KEY (`id_tipoconsulta`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `consulta`
--
ALTER TABLE `consulta`
  MODIFY `id_consulta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `hospital`
--
ALTER TABLE `hospital`
  MODIFY `id_hospital` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `paciente`
--
ALTER TABLE `paciente`
  MODIFY `id_paciente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tipo_consulta`
--
ALTER TABLE `tipo_consulta`
  MODIFY `id_tipoconsulta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `consulta`
--
ALTER TABLE `consulta`
  ADD CONSTRAINT `consulta_ibfk_1` FOREIGN KEY (`id_hospital`) REFERENCES `hospital` (`id_hospital`),
  ADD CONSTRAINT `consulta_ibfk_2` FOREIGN KEY (`id_tipoconsulta`) REFERENCES `tipo_consulta` (`id_tipoconsulta`);

--
-- Filtros para la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD CONSTRAINT `paciente_ibfk_1` FOREIGN KEY (`id_hospital`) REFERENCES `hospital` (`id_hospital`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
